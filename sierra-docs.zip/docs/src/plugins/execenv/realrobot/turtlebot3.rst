.. _plugins/execenv/realrobot/turtlebot3:

Turtlebot3
==========

This real robot plugin can be selected via ``--execenv=robot.turtlebot3``.  In
this execution environment, SIERRA will run experiments spread across multiple
turtlebots using GNU parallel.  The following environmental variables are used
in the turtlebot3 environment:

.. list-table::
   :widths: 25 25 25 25
   :header-rows: 1

   * - Environment variable

     - SIERRA context

     - Command line override

     - Notes

   * - :envvar:`SIERRA_NODEFILE`

     - Contains hostnames/IP address of all robots SIERRA can use. Same
       format as GNU parallel ``--sshloginfile``.

     - ``--nodefile``

     - :envvar:`SIERRA_NODEFILE` must be defined or
       :ref:`--nodefile<src/reference/cli:sierra---nodefile>` passed. If neither is true,
       SIERRA will throw an error.
